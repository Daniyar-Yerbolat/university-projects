#include <stdlib.h>
#include <stdbool.h>
#include "stack.h"

static int mockUp = 42;
static int *stackTop = &mockUp;


int getStackSize()
{
  return 0;
}

void setStackSize( int size)
{
}

void deleteStack()
{
}

int top()
{
   return *stackTop;
}

int pop( int *val)
{
  return 0;
}

int push( int val)
{
  return 0;
}
