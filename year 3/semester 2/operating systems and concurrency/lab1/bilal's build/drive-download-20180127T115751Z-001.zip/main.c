#include <stdio.h>
 
#include "linkedlist.h"
 
int main()
{
    struct node* head = NULL;
    int size, element;
    int counter = 0;
	char ch;
	
    printf("How big do you need your stack to be?:");
    scanf("%d",&size);
	printf("Stack creation successful\n");

	
 
    printf("--- Pushing values ---\n");
 
    init(head);
	
       while(counter < size)
    {
 
        printf("Enter a new value to the stack:");
        scanf("%d",&element);
        head = push(head,element);
        display(head);
        counter++;
    }
 
    printf("\n--- Popping values --- \n");
    while(empty(head) == 0)
    {   ch=fgetc(stdin);
	    if(ch=='\n'){
        head = pop(head,&element);
        printf("Now popping %d from stack.....\n",element);
        display(head);

		}
		
    }
 
    return 0;
}
   
		


				
	
 
		
        
	
		

		
	


 
   