#include <stdio.h>
struct node {
    int value;
    struct node * next;
};
 

void init(struct node* head)
{
    head = NULL;
}
 

struct node* push(struct node* head,int value)
{
    struct node* tmp = (struct node*)malloc(sizeof(struct node));
    if(tmp == NULL)
    {
        exit(0);
    }
    tmp->value = value;
    tmp->value = value;
    tmp->next = head;
    head = tmp;
    return head;
}

struct node* pop(struct node *head,int *element)
{
    struct node* tmp = head;
    *element = head->value;
    head = head->next;
    free(tmp);
    return head;
}
/*
    returns 1 if the stack is empty, otherwise returns 0
*/
int empty(struct node* head)
{
    return head == NULL ? 1 : 0;
}
 
/*
    display the stack content
*/
void display(struct node* head)
{
    struct node *current;
    current = head;
    if(current!= NULL)
    {
        printf("Values in stack: ");
        do
        {
            printf("%d ",current->value);
            current = current->next;
        }
        while (current!= NULL);
        printf("\n");
    }
    else
    {
        printf("The Stack is now empty! \n");
    }
 
}
