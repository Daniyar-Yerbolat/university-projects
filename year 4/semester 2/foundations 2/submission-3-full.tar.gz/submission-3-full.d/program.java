// The work of H00204990

import java.io.FileReader;
import java.io.*;
import java.text.ParseException;
import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONObject;

// The below code was taken from the sample
class program {

    private static Boolean simplifiedInput = false;
    @SuppressWarnings("ConstantConditions")
    private static String inputFileName = simplifiedInput ? "simple-input.json" : "input.json";
    @SuppressWarnings("ConstantConditions")
    private static String outputFileName = simplifiedInput ? "simple-output.txt" : "output.txt";

    private static Object setUpOutputAndReturnJsonInput ()
    {
        try {
            return new JSONParser().parse(new FileReader(inputFileName)); }
        catch (Exception exc) {
            System.err.print("\nERROR: something failed while getting the input: ");
            System.err.println(exc.getMessage());
            exc.printStackTrace();
            System.exit(1); }
        return null; }


    private static BufferedWriter bf;
    private static Exp[] variable_arr;

    private static boolean error_status = false;

    // Here starts my own code
    @SuppressWarnings("unchecked")
    public static void main (String[] args) throws IOException{
        Object jsonInput = setUpOutputAndReturnJsonInput ();

        FileWriter file = new FileWriter(outputFileName);
        bf = new BufferedWriter(file);

        JSONArray expressions = (JSONArray) ((JSONObject) jsonInput).get("declaration-list");
        Iterator<JSONObject> it = expressions.iterator();
        variable_arr = new Exp[expressions.size()];
        JSONObject temp;
        Node exp;
        Node val;
        int x = 0;
        Exp var_exp_val;
        while(it.hasNext()){
            temp = it.next();
            exp = expression((JSONObject)temp.get("expression"), null);
            val = eval(exp, null);
            var_exp_val = new Exp(exp,temp.get("declared-variable"),val);
            variable_arr[x] = var_exp_val;
            print(variable_arr[x]);
            x++;
        }
        bf.close();
        file.close();

        if(error_status){
            System.exit(new Random(System.currentTimeMillis()).nextInt(126) + 1);
        } else {
            System.exit(0);
        }
	}

	private static void print(Exp x) throws IOException{
        bf.write("Let ");
        bf.write("x");
        bf.write(String.valueOf(x.get_var_name()));
        bf.write(" be ");
        try {
            print_tree(x.get_exp());
            if(x.get_val() != null) {
                bf.write(" which is ");
                print_tree(x.get_val());
            } else {
                bf.write(" which has no value");
            }
            bf.write(".\n");
        } catch (java.text.ParseException e){
            error_status=true;
            bf.write(".\n");
            bf.write(e.getMessage());
            System.err.print("x");
            System.err.print(String.valueOf(x.get_var_name()));
            System.err.print(" - ");
            System.err.print(e.getMessage());}
    }

    private static void print_tree(Node x) throws IOException, ParseException {
        if(x.getType() == Type.NUM){
            if(x.getValue() < 0){error_status=true; throw new java.text.ParseException("ERROR: natural number must be greater than or equal zero.\n", 0);}
                bf.write(String.valueOf(x.getValue()));
        } else if(x.getType() == Type.EQUALS){
            if(x.get_children().size() != 2){error_status=true; throw new java.text.ParseException("ERROR: equality must have 2 arguments.\n", 0);}
            print_tree(x.get_children().get(0));
            bf.write(" = ");
            print_tree(x.get_children().get(1));
        } else if(x.getType() == Type.MEMBER){
            if(x.get_children().size() != 2){error_status=true; throw new java.text.ParseException("ERROR: membership must have 2 arguments.\n", 0);}
            print_tree(x.get_children().get(0));
            bf.write(" ∈ ");
            print_tree(x.get_children().get(1));
        } else if(x.getType() == Type.PAIR){
            if(x.get_children().size() != 2){error_status=true; throw new java.text.ParseException("ERROR: ordered pair must have 2 arguments.\n", 0);}
            bf.write("(");
            print_tree(x.get_children().get(0));
            bf.write(",");
            print_tree(x.get_children().get(1));
            bf.write(")");
        } else if(x.getType() == Type.SET){
            bf.write("{");
            Iterator<Node> it = x.get_children().iterator();
            if(it.hasNext()){
                print_tree(it.next());
            }
            while(it.hasNext()){
                bf.write(",");
                print_tree(it.next());
            }
            bf.write("}");
        } else if(x.getType() == Type.VARIABLE){
            if(x.getValue() < 0){error_status=true; throw new java.text.ParseException("ERROR: variable must be a natural number.\n", 0);}
            bf.write("x");
            bf.write(String.valueOf(x.getValue()));
        } else if(x.getType() == Type.FUNC){
            if(x.get_children().size() != 2){error_status=true; throw new java.text.ParseException("ERROR: function application must have 2 arguments.\n", 0);}
            print_tree(x.get_children().get(0));
            bf.write(" ");
            print_tree(x.get_children().get(1));
        } else if(x.getType() == Type.UNION){
            if(x.get_children().size() != 2){error_status=true; throw new java.text.ParseException("ERROR: union must have 2 arguments.\n", 0);}
            print_tree(x.get_children().get(0));
            bf.write(" ∪ ");
            print_tree(x.get_children().get(1));
        } else if(x.getType() == Type.DOMAIN){
            if(x.get_children().size() != 1){error_status=true; throw new java.text.ParseException("ERROR: domain must have 1 argument.\n", 0);}
            bf.write("domain(");
            print_tree(x.get_children().get(0));
            bf.write(")");
        } else if(x.getType() == Type.IS_FUNC){
            if(x.get_children().size() != 1){error_status=true; throw new java.text.ParseException("ERROR: function testing must have 1 argument.\n", 0);}
            bf.write("is-function(");
            print_tree(x.get_children().get(0));
            bf.write(")");
        } else if(x.getType() == Type.INVERSE){
            if(x.get_children().size() != 1){error_status=true; throw new java.text.ParseException("ERROR: inverse must have 1 argument.\n", 0);}
            bf.write("inverse(");
            print_tree(x.get_children().get(0));
            bf.write(")");
        } else if(x.getType() == Type.FUNC_SPACE){
            if(x.get_children().size() != 2){error_status=true; throw new java.text.ParseException("ERROR: function space must have 2 argument.\n", 0);}
            print_tree(x.get_children().get(0));
            bf.write(" ⇸ ");
            print_tree(x.get_children().get(1));
        } else if(x.getType() == Type.DIAGONALIZATION){
            if(x.get_children().size() != 4){error_status=true; throw new java.text.ParseException("ERROR: diagonalization must have 4 argument.\n", 0);}
            bf.write("diagonalize(");
            print_tree(x.get_children().get(0));
            bf.write(",");
            print_tree(x.get_children().get(1));
            bf.write(",");
            print_tree(x.get_children().get(2));
            bf.write(",");
            print_tree(x.get_children().get(3));
            bf.write(")");
        } else {
            error_status=true;
            throw new java.text.ParseException("ERROR: unknown symbol.\n", 0);
        }
    }

    // variable is the expression tree made in the expression function
    // value is the temp tree that stores the evaluated tree, before being added to the "database"
    // it is used to pass the reference of the parent node, to it's children
    // if it's null (like in membership or equality), then it is not added to evaluated tree.

	private static Node eval(Node variable, Node value){
        Node output = new Node(value, null, -1, null);


        if (variable.getType() == Type.NUM && variable.getValue() >= 0) {
                output.setValue(variable.getValue());
                output.setType(Type.NUM);
        } else if (variable.getType() == Type.PAIR && variable.get_children().size() == 2) {
            Node elem1, elem2;
            elem1 = eval(variable.get_children().get(0), output);
            elem2 = eval(variable.get_children().get(1), output);

            if(elem1 == null || elem2 == null){
                return null;
            }
                output.add_child(elem1);
                output.add_child(elem2);
                output.setType(Type.PAIR);
        } else if (variable.getType() == Type.SET) {
            //remove duplicates
            //Set<Node> temp = new HashSet<>(variable.get_children());
            Node elem;
            Node x2;
            for(Node x : variable.get_children()) {
                // the reason for adding x2 was to execute this bit of the code
                // variable node is an end node that only holds an integer reference to the variable
                // i want to get the full expression to check whether it exists first
                // that's the immediate solution that came to mind
                x2 = x;
                if(x.getType() == Type.VARIABLE){
                    x2 = eval(x, null);
                }
                // new code to check for duplicates
                if (!isSubtree(output, x2)) {
                    elem = eval(x, output);
                    if(elem == null) {
                        return null;
                    }
                    output.add_child(elem);
                }
            }
            output.setType(Type.SET);
        } else if ((variable.getType() == Type.EQUALS || variable.getType() == Type.MEMBER)  && variable.get_children().size() == 2) {
                boolean cond = false;

                Node elem1, elem2;
                elem1 = eval(variable.get_children().get(0), null);
                elem2 = eval(variable.get_children().get(1), null);

                // since equality allows no values to be checked against each other
                if((elem1 == null || elem2 == null) && variable.getType() == Type.MEMBER){
                    return null;
                }

                // false if parent is not a set
                if (variable.getType() == Type.MEMBER && (elem2 != null ? elem2.getType() : null) == Type.SET) {
                    // due to x1 ∈ x2, and isSubtree(parent, child)
                    cond = isSubtree(elem2, elem1);
                } else if (variable.getType() == Type.EQUALS) {
                    cond = areIdentical(elem1, elem2);
                }

            if (cond) {
                output.setValue(1);
            } else {
                output.setValue(0);
            }

            output.setType(Type.NUM);
        } else if (variable.getType() == Type.VARIABLE) {
            // find returns tuple - VARIABLE, EXPRESSION, VALUE
            // get_val returns the VALUE field, which is an evaluated tree.

            Exp temp = find(variable.getValue());
            if (temp == null){
                // variable not found
                return null;
            } else if(temp.get_val() == null){
                // variable has no value
                return null;
            } else {
                // not sure whether i should do that since i think i will be overwriting the original value
                // output = temp.get_val();
                // output.set_parent(value);
                // instead i make a copy of the object
                output = copy_node(temp.get_val(), value);

            }
        } else if (variable.getType() == Type.FUNC && variable.get_children().size() == 2) {
            Node elem1,elem2;
            elem1 = eval(variable.get_children().get(0), null);
            elem2 = eval(variable.get_children().get(1), null);

            if(elem1 == null || elem2 == null){
                return null;
            }

            Node x = search(elem1,elem2);
            if(x == null){
                return null;
            }

            output = x;
            x.set_parent(value);
        } else if (variable.getType() == Type.IS_FUNC && variable.get_children().size() == 1) {
            Node elem1;
            elem1 = eval(variable.get_children().get(0), null);

            if(elem1 == null){
                return null;
            }

            if (is_function(elem1)) {
                output.setValue(1);
            } else {
                output.setValue(0);
            }

            output.setType(Type.NUM);
        } else if (variable.getType() == Type.UNION && variable.get_children().size() == 2) {
            Node elem1,elem2;
            elem1 = eval(variable.get_children().get(0), null);
            elem2 = eval(variable.get_children().get(1), null);

            if(elem1 == null || elem2 == null){
                return null;
            }

            Node x = union(elem1,elem2);
            if(x == null){
                return null;
            }

            output = x;
            x.set_parent(value);
        } else if (variable.getType() == Type.DOMAIN && variable.get_children().size() == 1) {
            Node elem1;
            elem1 = eval(variable.get_children().get(0), null);

            if(elem1 == null){
                return null;
            }

            Node x = domain(elem1);

            if(x == null){
                return null;
            }

            output = x;
            x.set_parent(value);
        } else if (variable.getType() == Type.INVERSE && variable.get_children().size() == 1) {
            Node elem1;
            elem1 = eval(variable.get_children().get(0), null);

            if(elem1 == null){
                return null;
            }

            Node x = inverse(elem1);

            if(x == null){
                return null;
            }

            output = x;
            x.set_parent(value);
        } else if (variable.getType() == Type.FUNC_SPACE && variable.get_children().size() == 2) {
            Node elem1,elem2;
            elem1 = eval(variable.get_children().get(0), null);
            elem2 = eval(variable.get_children().get(1), null);

            if(elem1 == null || elem2 == null){
                return null;
            }

            Node x = function_space(elem1,elem2);
            if(x == null){
                return null;
            }

            output = x;
            x.set_parent(value);
        } else if (variable.getType() == Type.DIAGONALIZATION && variable.get_children().size() == 4) {
            Node elem1,elem2,elem3,elem4;
            elem1 = eval(variable.get_children().get(0), null);
            elem2 = eval(variable.get_children().get(1), null);
            elem3 = eval(variable.get_children().get(2), null);
            elem4 = eval(variable.get_children().get(3), null);

            if(elem1 == null || elem2 == null || elem3 == null || elem4 == null){
                return null;
            }

            Node x = diagonalize(elem1,elem2,elem3,elem4);
            if(x == null){
                return null;
            }

            output = x;
            x.set_parent(value);
        } else {
            return null;
        }
        return output;
    }

    private static Node function_space(Node elem1, Node elem2){
        if(elem1.getType() != Type.SET || elem2.getType() != Type.SET){
            return null;
        }

        Node output = new Node(null, null,-1, Type.SET);

        // TO DO

        return output;
    }

    private static Node diagonalize(Node elem1, Node elem2, Node elem3, Node elem4){
        if(elem1.getType() != Type.SET){
            return null;
        }

        Node output = new Node(null, null,-1, Type.SET);

        Node temp1, temp2, temp3, pair;
        for(Node i: elem1.get_children()) {
            temp1 = search(elem2, i);
            if(temp1 != null){
                temp2 = search(temp1,i);
                if(temp2 != null){
                    temp3 = search(elem3, temp2);
                    if(temp3 != null){
                        pair = new Node(output, null, -1, Type.PAIR);
                        pair.add_child(i);
                        pair.add_child(copy_node(temp3, output));
                        output.add_child(pair);
                    }
                } else {
                    pair = new Node(output, null, -1, Type.PAIR);
                    pair.add_child(i);
                    pair.add_child(copy_node(elem4, output));
                    output.add_child(pair);
                }
            } else {
                pair = new Node(output, null, -1, Type.PAIR);
                pair.add_child(i);
                pair.add_child(copy_node(elem4, output));
                output.add_child(pair);
            }
        }

        return output;
    }

    private static Node union(Node set1, Node set2){
        if(set1.getType() != Type.SET || set2.getType() != Type.SET){
            return null;
        }

        Node output = new Node(null, null,-1, Type.SET);

        for (Node x : set1.get_children()) {
            output.add_child(x);
        }
        for (Node x : set2.get_children()) {
            // the input of this function is already evaluated, so i can just add it as is
            // that said, i still have to check for duplicates when creating a new set
            if (!isSubtree(output, x)) {
                output.add_child(x);
            }
        }
        return output;
    }

    private static boolean is_function(Node set){

        if(set.getType() != Type.SET){
            return false;
        }

        Iterator<Node> it = set.get_children().iterator();
        Node temp = new Node(null, null, -1, Type.SET);
        Node x;
        while(it.hasNext()){
            x = it.next();

            if(x.getType() != Type.PAIR){
                return false;
            }

            for(Node x2: temp.get_children()){
                if(areIdentical(x2.get_children().get(0), x.get_children().get(0))){
                    return false;
                }
            }

            temp.add_child(x);
        }

        return true;
    }

    // exactly like is_function, but just checks whether the set is a binary relation or not
    // used by inverse and domain
    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    private static boolean is_binary_relation(Node set){
        if(set.getType() != Type.SET){
            return false;
        }

        Iterator<Node> it = set.get_children().iterator();
        Node x;
        while(it.hasNext()){
            x = it.next();
            if(x.getType() != Type.PAIR){
                return false;
            }
        }
        return true;
    }

    private static Node search(Node func, Node input){
        if(!is_function(func)){
            return null;
        }

        Iterator<Node> it = func.get_children().iterator();
        Node x;
        while(it.hasNext()){
            x = it.next();
            if(areIdentical(x.get_children().get(0),input)){
                return copy_node(x.get_children().get(1), null);
            }
        }
        return null;
    }

    private static Node domain(Node func){
        if(!is_binary_relation(func) && !is_function(func)){
            return null;
        }

        Iterator<Node> it = func.get_children().iterator();
        Node output = new Node(null,null,-1,Type.SET);
        Node x;
        while(it.hasNext()){
            x = it.next();
            output.add_child(x.get_children().get(0));
        }
        return output;
    }

    private static Node inverse(Node func){
        if(!is_binary_relation(func) && !is_function(func)){
            return null;
        }

        Iterator<Node> it = func.get_children().iterator();
        Node output = new Node(null,null,-1,Type.SET);
        Node x;
        Node reverse_pair;
        while(it.hasNext()){
            x = it.next();
            reverse_pair = new Node(output, null,-1,Type.PAIR);
            reverse_pair.add_child(x.get_children().get(1));
            reverse_pair.add_child(x.get_children().get(0));
            if (!isSubtree(output, reverse_pair)) {
                output.add_child(reverse_pair);
            }
        }
        return output;
    }
    /*Code for isSubtree and areIdentical were taken from this website
    * https://www.geeksforgeeks.org/check-if-a-binary-tree-is-subtree-of-another-binary-tree/
    *
    * it was edited since the code on the website is for binary trees
    * that said, it is not necessary for this task (part 1)
    * since we have no expressions inside expressions
    * */

    private static boolean isSubtree(Node parent, Node subset)
    {
        /* base cases */
        if (subset == null)
            return true;

        if (parent == null)
            return false;

        /* Check the tree with root as current node */
        if (areIdentical(parent, subset))
            return true;

        boolean output = false;
        for (Node child : parent.get_children()) {
            //output = output || isSubtree(child, subset);

            // i changed the logic to the membership function because it seemed more correct,
            // since with the above logic, 7 ∈ {{7}} will return true,
            // which i think is incorrect
            // now it only iterates through its own children, rather than recursively going through the whole tree
            output = output || areIdentical(child, subset);
        }
        return output;
    }

    private static boolean areIdentical(Node root1, Node root2)
    {

        /* base cases */
        if (root1 == null && root2 == null)
            return true;

        if (root1 == null || root2 == null)
            return false;


        boolean output = root1.getType() == root2.getType()
                && root1.getValue() == root2.getValue()
                && root1.get_children().size() == root2.get_children().size();

                // cannot check for parent since that messes up the membership code
                // since 6 and {6} will have different parents
                //&& root1.get_parent() == root2.get_parent();

        if (!output) {
            return false;
        }



        Iterator<Node> it1 = root1.get_children().iterator();
        Iterator<Node> it2 = root2.get_children().iterator();
        Node x, y;

        while(it1.hasNext() && it2.hasNext()){
            x = it1.next();
            y = it2.next();
            if (root1.getType() == Type.SET && root2.getType() == Type.SET){
                output = false;
                for(Node z: root2.get_children()){
                    output = output || areIdentical(x, z);
                }
                if (!output) {
                    return false;
                }
            } else {
                //optimization
                if (!output) {
                    return false;
                }
                // simplified output = output && areIdentical(x, y); since there is a check for output==false
                output = areIdentical(x, y);
            }
        }

        if(it1.hasNext() || it2.hasNext()){
            output = false;
        }
        return output;
    }
    @SuppressWarnings("SpellCheckingInspection")
    private static Node expression(JSONObject input, Node parent) {
        Node n = new Node(parent, null, -1,null);

        LinkedList<Node> children = null;
        if (input.get("expression-case").equals("natural-number")) {
            n = new Node(parent, null, input.get("natural-number"), Type.NUM);
        } else if (input.get("expression-case").equals("operation")) {
                children = args(input, n);
                if (input.get("operator").equals("pair")) {
                    n.setType(Type.PAIR);
                } else if (input.get("operator").equals("equal")) {
                    n.setType(Type.EQUALS);
                } else if (input.get("operator").equals("member")) {
                    n.setType(Type.MEMBER);
                } else if (input.get("operator").equals("apply-function")) {
                    n.setType(Type.FUNC);
                } else if (input.get("operator").equals("union")) {
                    n.setType(Type.UNION);
                } else if (input.get("operator").equals("set")) {
                    n.setType(Type.SET);
                } else if (input.get("operator").equals("inverse")) {
                    n.setType(Type.INVERSE);
                } else if (input.get("operator").equals("domain")) {
                    n.setType(Type.DOMAIN);
                } else if (input.get("operator").equals("is-function")) {
                    n.setType(Type.IS_FUNC);
                } else if(input.get("operator").equals("function-space")){
                    n.setType(Type.FUNC_SPACE);
                } else if(input.get("operator").equals("diagonalize")){
                    n.setType(Type.DIAGONALIZATION);
                }
        } else if (input.get("expression-case").equals("variable")) {
                n = new Node(parent, null, input.get("used-variable"), Type.VARIABLE);
        }
        n.add_children(children);
        return n;
    }

    private static Exp find(long var){
        int x = variable_arr.length-1;
        while(x >= 0){
            if(variable_arr[x] == null){
                x--;
                continue;
            } else if (variable_arr[x].get_var_name() == var){
                return variable_arr[x];
            }
            x--;
        }
        return null;
    }


    @SuppressWarnings("WhileLoopReplaceableByForEach")
    private static Node copy_node(Node old, Node new_parent_ref){
        Node new1 = new Node(new_parent_ref, null, old.getValue(), old.getType());
        Iterator<Node> it = old.get_children().iterator();
        while(it.hasNext()){
            new1.add_child(copy_node(it.next(), new1));
        }
        return new1;
    }

    @SuppressWarnings("unchecked")
    private static  LinkedList<Node> args(JSONObject input, Node parent){
        JSONArray args = (JSONArray) input.get("arguments");
        Iterator<JSONObject> it = args.iterator();
        LinkedList<Node> output = new LinkedList<>();
        Node temp;
        while(it.hasNext()) {
            temp = expression(it.next(), parent);
            output.add(temp);
        }
        return output;
    }
}

@SuppressWarnings("SpellCheckingInspection")
class Node{
    private Node parent;
    private LinkedList<Node> children;
    private long value;
    private Type type;

    Node(Node myparent, LinkedList<Node>  mychildren, Object myvalue, Type mytype){
        value = Long.parseLong(myvalue.toString());
        parent = myparent;
        children = new LinkedList<>();
        add_children(mychildren);
        type = mytype;
    }

    void add_children(LinkedList<Node> child){
        if(child != null){
            children.addAll(child);
        }
    }
    void add_child(Node child){
        if(child != null){
            children.add(child);
        }
    }

    Type getType(){
        return type;
    }

    void setType(Type mytype){
        type = mytype;
    }

    LinkedList<Node> get_children(){
        return children;
    }

    long getValue(){
        return value;
    }

    void setValue(long value){
        this.value = value;
    }

    @SuppressWarnings("unused")
    Node get_parent(){
        return parent;
    }

    @SuppressWarnings("unused")
    void set_parent(Node parent){
        this.parent = parent;
    }
}

class Exp{
    private Node exp;
    private long var_name;
    private Node value;

    Exp(Node exp, Object var_name, Node value){
        this.exp = exp;
        this.var_name = Long.parseLong(var_name.toString());
        this.value = value;
    }

    Node get_exp(){
        return exp;
    }

    Node get_val(){
        return value;
    }

    long get_var_name(){
        return var_name;
    }
}
@SuppressWarnings("SpellCheckingInspection")
enum Type {
    SET, PAIR, NUM, EQUALS, MEMBER, VARIABLE, FUNC, IS_FUNC, DOMAIN, INVERSE, UNION, FUNC_SPACE, DIAGONALIZATION
}