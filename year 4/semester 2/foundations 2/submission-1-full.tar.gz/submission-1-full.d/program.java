// The work of H00204990

import java.io.FileReader;
import java.io.*;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONObject;

// The below code was taken from the sample
class program {

    static Boolean simplifiedInput = false;
    static String inputFileName = simplifiedInput ? "simple-input.json" : "input.json";
    static String outputFileName = simplifiedInput ? "simple-output.txt" : "output.txt";

    static Object setUpOutputAndReturnJsonInput ()
    {
       /* try {
            // duplicate standard output (Linux file descriptor 1) to the output file
            System.setOut(new PrintStream(new ProcessBuilder("tee",outputFileName)
                                          .inheritIO()
                                          .redirectInput(ProcessBuilder.Redirect.PIPE)
                                          .start()
                                          .getOutputStream(),
                                          true // automatically flush output
                                          , "UTF-8"));
            // *** MAYBE duplicate standard error (Linux file descriptor 2) to the output file?
        }
        catch (java.io.IOException exc
               // throws java.io.IOException, java.io.UnsupportedEncodingException
               ) {
            System.err.print("\nERROR: something failed while setting up the output: ");
            System.err.println(exc.getMessage());
            exc.printStackTrace();
            System.exit(1); }
            */
        try {
            return new JSONParser().parse(new FileReader(inputFileName)); }
        catch (Exception exc) {
            System.err.print("\nERROR: something failed while getting the input: ");
            System.err.println(exc.getMessage());
            exc.printStackTrace();
            System.exit(1); }
        return null; }


    private static FileWriter file;
    private static BufferedWriter bf;
    private static Node[] variable_arr;

    // Here starts my own code
    public static void main (String[] args) throws Exception{
        Object jsonInput = setUpOutputAndReturnJsonInput ();

        file = new FileWriter(outputFileName);
        bf = new BufferedWriter(file);

        JSONArray expressions = (JSONArray) ((JSONObject) jsonInput).get("declaration-list");
        Iterator<JSONObject> it = expressions.iterator();
        JSONObject temp;
        variable_arr = new Node[expressions.size()];
        int x = 0;
        while(it.hasNext()){
            //Let VARIABLE be EXPRESSION which is VALUE.
            //Let VARIABLE be EXPRESSION which has no value.

            temp = it.next();
            bf.write("Let ");
            bf.write("x");
            bf.write(temp.get("declared-variable").toString());
            bf.write(" be ");

            variable_arr[x] = expression((JSONObject)temp.get("expression"), null, temp.get("declared-variable").toString());

            if(variable_arr[x].getType() != null){
                bf.write(" which is ");
                eval(variable_arr[x]);
            } else {
                bf.write(" which has no value");
            }
            bf.write(".");
            bf.write("\n");

            x++;
        }
        bf.close();
        file.close();
	}

	private static void eval(Node variable) throws Exception{
        if (variable.getType() == Type.NUM){
                bf.write(variable.getValue().toString());
        } else if (variable.getType() == Type.PAIR){
                bf.write("(");
                eval(variable.get_children().get(0));
                bf.write(",");
                eval(variable.get_children().get(1));
                bf.write(")");
        } else if (variable.getType() == Type.SET){
                Set temp = new HashSet(variable.get_children());
                bf.write("{");
                Iterator<Node> it = temp.iterator();
                    if(it.hasNext()){
                        eval(it.next());
                    }
                    while(it.hasNext()) {
                        bf.write(",");;
                        eval(it.next());
                    }
                bf.write("}");
                    // EXP are all variables with just a natural number
        } else if (variable.getType() == Type.EXP){
            eval(variable.get_children().get(0));
        }
    }


    /*Code for isSubtree and areIdentical were taken from this website
    * https://www.geeksforgeeks.org/check-if-a-binary-tree-is-subtree-of-another-binary-tree/
    *
    * it was edited since the code on the website is for binary trees
    * that said, it is not necessary for this task (part 1)
    * since we have no expressions inside expressions
    * */

    boolean isSubtree(Node parent, Node subset)
    {
        /* base cases */
        if (subset == null)
            return true;

        if (parent == null)
            return false;

        /* Check the tree with root as current node */
        if (areIdentical(parent, subset))
            return true;

        boolean output = false;
        for (Node child : parent.get_children()) {
            output = output || isSubtree(child, subset);
        }
        return output;
    }

    boolean areIdentical(Node root1, Node root2)
    {

        /* base cases */
        if (root1 == null && root2 == null)
            return true;

        if (root1 == null || root2 == null)
            return false;

        boolean output = (root1.getValue() == root2.getValue());
        Iterator<Node> it1 = root1.get_children().iterator();
        Iterator<Node> it2 = root2.get_children().iterator();
        while(it1.hasNext() && it2.hasNext()){
            output = output && areIdentical(it1.next(), it2.next());
        }

        if(it1.hasNext() || it2.hasNext()){
            output = false;
        }
        return output;
    }

    private static Node expression(JSONObject input, Node parent, String variablename) throws Exception {
        Node n = new Node(null, null, variablename, null);

        LinkedList<Node> child = null;
        if (input.get("expression-case").equals("natural-number")) {
            child = new LinkedList<Node>();
            child.add(nat((JSONObject) input, n));
            n.setType(Type.EXP);
        } else if (input.get("expression-case").equals("operation")) {
            if (input.get("operator").equals("pair")) {
                child = pair((JSONObject) input, n);
                n.setType(Type.PAIR);
            } else if (input.get("operator").equals("set")) {
                child = set((JSONObject) input, n);
                n.setType(Type.SET);
            }
        }
        n.add_children(child);
        return n;
    }

	private static Node nat(JSONObject input, Node parent) throws Exception{
        bf.write(input.get("natural-number").toString());
        return new Node(parent, null, input.get("natural-number"), Type.NUM);
    }

    private static  LinkedList<Node> pair(JSONObject input, Node parent) throws Exception{
        bf.write("(");
        LinkedList<Node> output = common_set_pair(input, parent);
        bf.write(")");
        return output;
    }

    private static  LinkedList<Node> set(JSONObject input, Node parent) throws Exception{
        bf.write("{");
        LinkedList<Node> output = common_set_pair(input, parent);
        bf.write("}");
        return output;
    }

    private static LinkedList<Node> common_set_pair(JSONObject input, Node parent) throws Exception{
        JSONArray args = (JSONArray) input.get("arguments");
        Iterator<JSONObject> it = args.iterator();
        LinkedList<Node> output = new LinkedList<Node>();
        Node temp;
        if(it.hasNext()){
            temp = expression(it.next(), parent, null);
            temp.set_parent(parent);
            output.add(temp);
        }
        while(it.hasNext()) {
            bf.write(",");;
            temp = expression(it.next(), parent,null);
            temp.set_parent(parent);
            output.add(temp);
        }
        return output;
    }
}

class Node{
    private Node parent;
    private LinkedList<Node> children;
    private Object value;
    private Type type;
    Node(Node myparent, LinkedList<Node>  mychildren, Object myvalue, Type mytype){
        children = new LinkedList();
        value = myvalue;
        parent = myparent;
        if(mychildren!=null){children.addAll(mychildren);}
        type = mytype;
    }

    public void add_children(LinkedList<Node> child){
        children.addAll(child);
    }

    public Type getType(){
        return type;
    }

    public void setType(Type mytype){
        type = mytype;
    }

    public LinkedList<Node> get_children(){
        return children;
    }

    public Object getValue(){
        return value;
    }

    public Node get_parent(){
        return parent;
    }

    public void set_parent(Node parent){
        this.parent = parent;
    }
}

enum Type {
    EXP, SET, PAIR, NUM
}